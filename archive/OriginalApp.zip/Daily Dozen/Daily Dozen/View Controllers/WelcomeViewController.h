//
//  WelcomeViewController.h
//  Daily Dozen
//
//  Created by Chan Kruse on 2015-10-06.
//  Copyright © 2015 NutritionFacts.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

@end
