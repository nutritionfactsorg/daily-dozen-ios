//
//  ColorConstants.h
//  Daily Dozen
//
//  Created by Chan Kruse on 2015-10-02.
//  Copyright © 2015 NutritionFacts.org. All rights reserved.
//


#define kColorNavBar [UIColor colorWithRed:127.0/255.0 green:192.0/255.0 blue:76.0/255.0 alpha:1.0]
#define kColorAccent [UIColor colorWithRed:255.0/255.0 green:193.0/255.0 blue:7.0/255.0 alpha:1.0]