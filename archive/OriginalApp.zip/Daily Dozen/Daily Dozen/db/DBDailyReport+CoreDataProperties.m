//
//  DBDailyReport+CoreDataProperties.m
//  Daily Dozen
//
//  Created by Chan Kruse on 2015-10-04.
//  Copyright © 2015 NutritionFacts.org. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "DBDailyReport+CoreDataProperties.h"

@implementation DBDailyReport (CoreDataProperties)

@dynamic date;
@dynamic consumptions;
@dynamic user;

@end
