//
//  DBUser.m
//  Daily Dozen
//
//  Created by Chan Kruse on 2015-10-02.
//  Copyright © 2015 NutritionFacts.org. All rights reserved.
//

#import "DBUser.h"
#import "DBDailyReport.h"

@implementation DBUser

// Insert code here to add functionality to your managed object subclass

@end
