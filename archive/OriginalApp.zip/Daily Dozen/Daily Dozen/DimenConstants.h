//
//  DimenConstants.h
//  Daily Dozen
//
//  Created by Chan Kruse on 2015-10-04.
//  Copyright © 2015 NutritionFacts.org. All rights reserved.
//

#ifndef DimenConstants_h
#define DimenConstants_h

#define kDimenRowVerticalSpacer 15.f
#define kDimenCellLeftSpacer  15.f
#define kDimenCellRightSpacer  15.f

#endif /* DimenConstants_h */
